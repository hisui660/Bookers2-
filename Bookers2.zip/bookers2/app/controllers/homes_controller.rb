class HomesController < ApplicationController
  def top
  end
  
  def create
    @book = Book.new(post_image_params)
    @book.user_id = current_user.id
    @book.save
    redirect_to book_path
  end
  
  def about
  end
end
