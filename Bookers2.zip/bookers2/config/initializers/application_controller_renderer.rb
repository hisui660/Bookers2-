# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '51353ac6b59d87440cf8de58e6c9fac12eada64c9b0c8db317f1cbfb44aaffd2f69c1dd9e1e07f83ea36b81de748e7c7addb471efe44ea183c5d8b74f20244f6'